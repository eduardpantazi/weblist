<hr>
<p>Copyright &copy; 2018 <b>Eduard Pantazi</b>. <span class="text-muted">Developed using Codeigniter 3.1.6 and PHP 7.2</span></p>
</div>
</body>
</html>